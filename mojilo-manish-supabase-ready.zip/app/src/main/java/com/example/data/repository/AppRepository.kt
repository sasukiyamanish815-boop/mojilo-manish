package com.example.data.repository

import android.content.Context
import android.content.SharedPreferences
import com.example.data.models.*
import com.example.data.remote.SupabaseClient
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.UUID

class AppRepository(private val context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("mojilo_manish_prefs", Context.MODE_PRIVATE)

    private val moshi = Moshi.Builder().add(KotlinJsonAdapterFactory()).build()
    private val userAdapter = moshi.adapter(UserProfile::class.java)

    fun getDeviceId(): String {
        var deviceId = prefs.getString("device_id", null)
        if (deviceId.isNullOrBlank()) {
            deviceId = UUID.randomUUID().toString()
            prefs.edit().putString("device_id", deviceId).apply()
        }
        return deviceId
    }

    fun getSavedUserSession(): UserProfile? {
        val json = prefs.getString("user_session", null) ?: return null
        return try {
            userAdapter.fromJson(json)
        } catch (e: Exception) {
            null
        }
    }

    fun saveUserSession(user: UserProfile) {
        val json = userAdapter.toJson(user)
        prefs.edit().putString("user_session", json).apply()
    }

    fun clearUserSession() {
        prefs.edit().remove("user_session").apply()
    }

    // AUTH / LOGIN (Device Lock Enforced on Server)
    suspend fun login(mobile: String, pass: String): Result<UserProfile> = withContext(Dispatchers.IO) {
        val thisDeviceId = getDeviceId()
        try {
            val api = SupabaseClient.getApi(context)
            val response = api.getProfileByMobile("eq.$mobile")

            if (response.isSuccessful) {
                val profiles = response.body()
                val profile = profiles?.firstOrNull { it.password == pass }

                if (profile == null) {
                    return@withContext Result.failure(Exception("મોબાઈલ નંબર અથવા પાસવર્ડ ખોટો છે."))
                }

                if (!profile.isActive) {
                    return@withContext Result.failure(Exception("આ એકાઉન્ટ નિષ્ક્રિય (Inactive) છે. કૃપા કરીને Admin નો સંપર્ક કરો."))
                }

                // DEVICE LOCK CHECK:
                if (!profile.activeDeviceId.isNullOrBlank() && profile.activeDeviceId != thisDeviceId) {
                    return@withContext Result.failure(
                        Exception("આ account હાલમાં બીજા મોબાઈલમાં login છે. કૃપા કરીને પહેલા જૂના મોબાઈલમાંથી Logout કરો.")
                    )
                }

                api.updateProfile("eq.${profile.id}", mapOf("active_device_id" to thisDeviceId))

                val updatedUser = profile.copy(activeDeviceId = thisDeviceId)
                saveUserSession(updatedUser)
                return@withContext Result.success(updatedUser)
            } else {
                return@withContext loginFallback(mobile, pass, thisDeviceId)
            }
        } catch (e: Exception) {
            return@withContext loginFallback(mobile, pass, thisDeviceId)
        }
    }

    // LOGOUT: Clears active_device_id session ONLY. NEVER DELETES DATA!
    suspend fun logout(user: UserProfile): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val api = SupabaseClient.getApi(context)
            api.updateProfile("eq.${user.id}", mapOf("active_device_id" to null))
        } catch (_: Exception) {
        } finally {
            clearUserSession()
        }
        return@withContext Result.success(Unit)
    }

    // STUDENT: Get Tests with Completed Status
    suspend fun getStudentTests(studentId: String): Result<List<TestWithStatus>> = withContext(Dispatchers.IO) {
        try {
            val api = SupabaseClient.getApi(context)
            val testsRes = api.getTests()
            val completedRes = api.getCompletedTestsForStudent("eq.$studentId")

            if (testsRes.isSuccessful) {
                val allTests = testsRes.body()?.filter { it.isActive } ?: emptyList()
                val completedTestIds = (completedRes.body() ?: emptyList()).map { it.testId }.toSet()

                val resultList = allTests.map { test ->
                    TestWithStatus(
                        test = test,
                        isCompleted = completedTestIds.contains(test.id)
                    )
                }
                return@withContext Result.success(resultList)
            } else {
                return@withContext Result.success(getFallbackStudentTests(studentId))
            }
        } catch (e: Exception) {
            return@withContext Result.success(getFallbackStudentTests(studentId))
        }
    }

    // STUDENT: Get Questions
    suspend fun getQuestionsForTest(testId: String): Result<List<QuestionItem>> = withContext(Dispatchers.IO) {
        try {
            val api = SupabaseClient.getApi(context)
            val response = api.getQuestionsForTest("eq.$testId")

            if (response.isSuccessful && response.body() != null) {
                return@withContext Result.success(response.body()!!)
            } else {
                return@withContext Result.success(getFallbackQuestions(testId))
            }
        } catch (e: Exception) {
            return@withContext Result.success(getFallbackQuestions(testId))
        }
    }

    // STUDENT: Submit Test
    // STRICT RULE: Store ONLY student_id and test_id in completed_tests table.
    // NO marks, NO answers, NO scores saved in database!
    suspend fun submitTest(
        studentId: String,
        testId: String,
        questions: List<QuestionItem>,
        selectedAnswers: Map<String, Int>
    ): Result<TestScoreResult> = withContext(Dispatchers.IO) {
        var correctCount = 0
        var totalObtainedMarks = 0
        var totalPossibleMarks = 0

        questions.forEach { q ->
            totalPossibleMarks += q.marks
            val chosen = selectedAnswers[q.id]
            if (chosen != null && chosen == q.correctOptionIndex) {
                correctCount++
                totalObtainedMarks += q.marks
            }
        }

        try {
            val api = SupabaseClient.getApi(context)
            val record = CompletedTestStatus(
                studentId = studentId,
                testId = testId
            )
            api.recordTestCompletion(record)
        } catch (_: Exception) {
            recordFallbackTestCompletion(studentId, testId)
        }

        val testTitle = getFallbackTestTitle(testId)

        val scoreResult = TestScoreResult(
            testTitle = testTitle,
            totalQuestions = questions.size,
            correctAnswersCount = correctCount,
            obtainedMarks = totalObtainedMarks,
            totalPossibleMarks = totalPossibleMarks
        )

        return@withContext Result.success(scoreResult)
    }

    // ADMIN: Student Management
    suspend fun adminGetStudents(): Result<List<UserProfile>> = withContext(Dispatchers.IO) {
        try {
            val api = SupabaseClient.getApi(context)
            val res = api.getProfiles()
            if (res.isSuccessful && res.body() != null) {
                return@withContext Result.success(res.body()!!.filter { it.role == "student" })
            } else {
                return@withContext Result.success(fallbackStudents)
            }
        } catch (e: Exception) {
            return@withContext Result.success(fallbackStudents)
        }
    }

    suspend fun adminAddStudent(name: String, mobile: String, pass: String): Result<UserProfile> = withContext(Dispatchers.IO) {
        val newStudent = UserProfile(
            id = UUID.randomUUID().toString(),
            name = name,
            mobileNumber = mobile,
            password = pass,
            role = "student",
            isActive = true
        )
        try {
            val api = SupabaseClient.getApi(context)
            api.createProfile(newStudent)
        } catch (_: Exception) {}

        fallbackStudents.add(newStudent)
        return@withContext Result.success(newStudent)
    }

    suspend fun adminUpdateStudent(id: String, name: String, mobile: String, pass: String, isActive: Boolean): Result<Unit> = withContext(Dispatchers.IO) {
        val updates = mapOf(
            "name" to name,
            "mobile_number" to mobile,
            "password" to pass,
            "is_active" to isActive
        )
        try {
            val api = SupabaseClient.getApi(context)
            api.updateProfile("eq.$id", updates)
        } catch (_: Exception) {}

        val index = fallbackStudents.indexOfFirst { it.id == id }
        if (index != -1) {
            fallbackStudents[index] = fallbackStudents[index].copy(
                name = name,
                mobileNumber = mobile,
                password = pass,
                isActive = isActive
            )
        }
        return@withContext Result.success(Unit)
    }

    suspend fun adminDeleteStudent(id: String): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val api = SupabaseClient.getApi(context)
            api.deleteProfile("eq.$id")
        } catch (_: Exception) {}

        fallbackStudents.removeAll { it.id == id }
        return@withContext Result.success(Unit)
    }

    suspend fun adminResetStudentDeviceLock(id: String): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val api = SupabaseClient.getApi(context)
            api.updateProfile("eq.$id", mapOf("active_device_id" to null))
        } catch (_: Exception) {}

        val index = fallbackStudents.indexOfFirst { it.id == id }
        if (index != -1) {
            fallbackStudents[index] = fallbackStudents[index].copy(activeDeviceId = null)
        }
        return@withContext Result.success(Unit)
    }

    // ADMIN: Test Management
    suspend fun adminGetTests(): Result<List<TestItem>> = withContext(Dispatchers.IO) {
        try {
            val api = SupabaseClient.getApi(context)
            val res = api.getTests()
            if (res.isSuccessful && res.body() != null) {
                return@withContext Result.success(res.body()!!)
            } else {
                return@withContext Result.success(fallbackTests)
            }
        } catch (e: Exception) {
            return@withContext Result.success(fallbackTests)
        }
    }

    suspend fun adminCreateTest(title: String, isActive: Boolean, reattemptAllowed: Boolean): Result<TestItem> = withContext(Dispatchers.IO) {
        val newTest = TestItem(
            id = UUID.randomUUID().toString(),
            title = title,
            isActive = isActive,
            reattemptAllowed = reattemptAllowed
        )
        try {
            val api = SupabaseClient.getApi(context)
            api.createTest(newTest)
        } catch (_: Exception) {}

        fallbackTests.add(0, newTest)
        return@withContext Result.success(newTest)
    }

    suspend fun adminUpdateTest(id: String, title: String, isActive: Boolean, reattemptAllowed: Boolean): Result<Unit> = withContext(Dispatchers.IO) {
        val updates = mapOf(
            "title" to title,
            "is_active" to isActive,
            "reattempt_allowed" to reattemptAllowed
        )
        try {
            val api = SupabaseClient.getApi(context)
            api.updateTest("eq.$id", updates)
        } catch (_: Exception) {}

        val idx = fallbackTests.indexOfFirst { it.id == id }
        if (idx != -1) {
            fallbackTests[idx] = fallbackTests[idx].copy(
                title = title,
                isActive = isActive,
                reattemptAllowed = reattemptAllowed
            )
        }
        return@withContext Result.success(Unit)
    }

    suspend fun adminDeleteTest(id: String): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val api = SupabaseClient.getApi(context)
            api.deleteTest("eq.$id")
        } catch (_: Exception) {}

        fallbackTests.removeAll { it.id == id }
        fallbackQuestions.removeAll { it.testId == id }
        return@withContext Result.success(Unit)
    }

    // ADMIN: Question Management
    suspend fun adminAddQuestion(
        testId: String,
        qText: String,
        options: List<String>,
        correctIndex: Int,
        marks: Int
    ): Result<QuestionItem> = withContext(Dispatchers.IO) {
        val q = QuestionItem(
            id = UUID.randomUUID().toString(),
            testId = testId,
            questionText = qText,
            options = options,
            correctOptionIndex = correctIndex,
            marks = marks
        )
        try {
            val api = SupabaseClient.getApi(context)
            api.createQuestion(q)
        } catch (_: Exception) {}

        fallbackQuestions.add(q)
        return@withContext Result.success(q)
    }

    suspend fun adminUpdateQuestion(
        id: String,
        testId: String,
        qText: String,
        options: List<String>,
        correctIndex: Int,
        marks: Int
    ): Result<Unit> = withContext(Dispatchers.IO) {
        val updates = mapOf(
            "question_text" to qText,
            "options" to options,
            "correct_option_index" to correctIndex,
            "marks" to marks
        )
        try {
            val api = SupabaseClient.getApi(context)
            api.updateQuestion("eq.$id", updates)
        } catch (_: Exception) {}

        val idx = fallbackQuestions.indexOfFirst { it.id == id }
        if (idx != -1) {
            fallbackQuestions[idx] = fallbackQuestions[idx].copy(
                questionText = qText,
                options = options,
                correctOptionIndex = correctIndex,
                marks = marks
            )
        }
        return@withContext Result.success(Unit)
    }

    suspend fun adminDeleteQuestion(id: String, testId: String): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val api = SupabaseClient.getApi(context)
            api.deleteQuestion("eq.$id")
        } catch (_: Exception) {}

        fallbackQuestions.removeAll { it.id == id }
        return@withContext Result.success(Unit)
    }

    // ---- FALLBACK IN-MEMORY STORE FOR DEMO/OFFLINE TESTING ----
    companion object {
        val adminUser = UserProfile(
            id = "admin-1",
            name = "Mojilo Admin",
            mobileNumber = "7096684982",
            password = "Manish@2006",
            role = "admin",
            isActive = true
        )

        val demoStudent = UserProfile(
            id = "student-1",
            name = "વિદ્યાર્થી (Demo Student)",
            mobileNumber = "9876543210",
            password = "123456",
            role = "student",
            isActive = true
        )

        val fallbackStudents = mutableListOf(demoStudent)

        val test1 = TestItem(
            id = "test-101",
            title = "સામાન્ય જ્ઞાન પરીક્ષા (General Knowledge Quiz 1)",
            isActive = true,
            reattemptAllowed = false
        )

        val test2 = TestItem(
            id = "test-102",
            title = "ગુજરાત ઇતિહાસ અને સંસ્કૃતિ (Gujarat History Test)",
            isActive = true,
            reattemptAllowed = true
        )

        val test3 = TestItem(
            id = "test-103",
            title = "ગણિત અને તર્કશક્તિ (Maths & Reasoning Test)",
            isActive = true,
            reattemptAllowed = true
        )

        val fallbackTests = mutableListOf(test1, test2, test3)

        val fallbackQuestions = mutableListOf(
            QuestionItem(
                id = "q-101-1",
                testId = "test-101",
                questionText = "ગુજરાત રાજ્યનું પાટનગર કયું છે?",
                options = listOf("અમદાવાદ", "ગાંધીનગર", "સુરત", "વડોદરા"),
                correctOptionIndex = 1,
                marks = 5
            ),
            QuestionItem(
                id = "q-101-2",
                testId = "test-101",
                questionText = "ભારતના રાષ્ટ્રપિતા કોણ છે?",
                options = listOf("સરદાર વલ્લભભાઈ પટેલ", "મહાત્મા ગાંધી", "જવાહરલાલ નેહરુ", "ડૉ. બી. આર. આંબેડકર"),
                correctOptionIndex = 1,
                marks = 5
            ),
            QuestionItem(
                id = "q-101-3",
                testId = "test-101",
                questionText = "વિશ્વનો સૌથી મોટો મહાસાગર કયો છે?",
                options = listOf("એટલાન્ટિક મહાસાગર", "હિંદ મહાસાગર", "પેસિફિક મહાસાગર", "આર્કટિક મહાસાગર"),
                correctOptionIndex = 2,
                marks = 5
            ),
            QuestionItem(
                id = "q-101-4",
                testId = "test-101",
                questionText = "સૂર્ય કઈ દિશામાં ઊગે છે?",
                options = listOf("પશ્ચિમ", "ઉત્તર", "દક્ષિણ", "પૂર્વ"),
                correctOptionIndex = 3,
                marks = 5
            ),

            QuestionItem(
                id = "q-102-1",
                testId = "test-102",
                questionText = "સ્ટેચ્યુ ઓફ યુનિટી કઈ નદીના કિનારે આવેલું છે?",
                options = listOf("સાબરમતી", "તાપી", "નર્મદા", "મહી"),
                correctOptionIndex = 2,
                marks = 5
            ),
            QuestionItem(
                id = "q-102-2",
                testId = "test-102",
                questionText = "ગીર રાષ્ટ્રીય ઉદ્યાન કયા પ્રાણી માટે પ્રખ્યાત છે?",
                options = listOf("એશિયાઈ સિંહ", "વાઘ", "એકશિંગી ગેંડો", "હાથી"),
                correctOptionIndex = 0,
                marks = 5
            ),

            QuestionItem(
                id = "q-103-1",
                testId = "test-103",
                questionText = "12 x 12 ની કિંમત શું થાય?",
                options = listOf("124", "144", "154", "164"),
                correctOptionIndex = 1,
                marks = 10
            )
        )

        val fallbackCompletedSet = mutableSetOf<String>()
    }

    private fun loginFallback(mobile: String, pass: String, thisDeviceId: String): Result<UserProfile> {
        val allUsers = listOf(adminUser) + fallbackStudents
        val user = allUsers.firstOrNull { it.mobileNumber == mobile && it.password == pass }
            ?: return Result.failure(Exception("મોબાઈલ નંબર અથવા પાસવર્ડ ખોટો છે."))

        if (!user.isActive) {
            return Result.failure(Exception("આ એકાઉન્ટ નિષ્ક્રિય (Inactive) છે. કૃપા કરીને Admin નો સંપર્ક કરો."))
        }

        if (!user.activeDeviceId.isNullOrBlank() && user.activeDeviceId != thisDeviceId) {
            return Result.failure(
                Exception("આ account હાલમાં બીજા મોબાઈલમાં login છે. કૃપા કરીને પહેલા જૂના મોબાઈલમાંથી Logout કરો.")
            )
        }

        val updated = user.copy(activeDeviceId = thisDeviceId)
        if (updated.role == "student") {
            val idx = fallbackStudents.indexOfFirst { it.id == user.id }
            if (idx != -1) fallbackStudents[idx] = updated
        }
        saveUserSession(updated)
        return Result.success(updated)
    }

    private fun getFallbackStudentTests(studentId: String): List<TestWithStatus> {
        return fallbackTests.filter { it.isActive }.map { test ->
            val isComp = fallbackCompletedSet.contains("${studentId}_${test.id}")
            TestWithStatus(test, isComp)
        }
    }

    private fun getFallbackQuestions(testId: String): List<QuestionItem> {
        return fallbackQuestions.filter { it.testId == testId }
    }

    private fun recordFallbackTestCompletion(studentId: String, testId: String) {
        fallbackCompletedSet.add("${studentId}_${testId}")
    }

    private fun getFallbackTestTitle(testId: String): String {
        return fallbackTests.firstOrNull { it.id == testId }?.title ?: "પરીક્ષા (Test)"
    }
}
